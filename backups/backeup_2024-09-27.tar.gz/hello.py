num1 = float(input("enter first number: "))
num2 = float(input("enter second number: "))

sum = (num1 / num2)
print("dividation of number is:",sum)