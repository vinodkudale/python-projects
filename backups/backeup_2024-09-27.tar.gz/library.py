import os

print(os.system('date'))