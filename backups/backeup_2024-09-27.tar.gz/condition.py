week_day = input("enter day: ")
if week_day == "monday":
   print("i will learn devops")
else:
   print("i will learn aws")