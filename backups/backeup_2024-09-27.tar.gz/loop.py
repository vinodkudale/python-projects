list_cloud = ["aws","gcp","ibm"]
print(list_cloud)

list_cloud.append("alibaba cloud")
print(list_cloud)

list_cloud.insert(0,"saleforce")
print(list_cloud)

print(len(list_cloud))

for cloud in list_cloud:
    print(cloud)

for i in range(1,11):
    print(i)